
public class EmployeeApp {
	//array capacity
	private static final int NumberOfEmployee = 5;

	//actual number of employees
	private int eCount = 0;
	private Employee[] emp_list = new Employee[NumberOfEmployee];
	
	/**
	 * Constructor
	 */
	public EmployeeApp(){}

	/**
	 * Constructor
	 * @param employees
	 */
	public EmployeeApp(Employee[] employees)  throws IndexOutOfBoundsException{
		// Throw exception if capacity is reached
		if (employees.length >= NumberOfEmployee) 
			throw new IndexOutOfBoundsException("Out of boundary");
		
		for(Employee e : employees){
			emp_list[eCount++] = e;
		}
	}
	
	/**
	 * This method adds a Employee object to the employees array
	 * @param name
	 * @param salary
	 * @throws IndexOutOfBoundsException
	 */
	public void addEmployee(String name, double salary) throws IndexOutOfBoundsException{
		// Throw exception if capacity is reached
		if (eCount == NumberOfEmployee) 
			throw new IndexOutOfBoundsException("Out of boundary");
		emp_list[eCount] = new Employee(eCount+1, name, salary);
		eCount++;
	}
	
	/**
	 * This method retrieves minimum salary of employees
	 * @return - int - minimum salary
	 */
	public double getMinSalary(){
		double result = 0;
		int idx = 0;
		for(Employee e : emp_list){
			if(idx++ < eCount){
				if (result == 0)
					result = e.getSalary();
				if (e.getSalary() < result) 
					result = e.getSalary();
			}
		}
		return result;
	}

	/**
	 * This method retrieves maximum salary of employees
	 * @return - int - maximum salary
	 */
	public double getMaxSalary(){
		double result = 0;
		int idx = 0;
		for(Employee e : emp_list){
			if(idx++ < eCount)
				if (e.getSalary() > result) 
					result = e.getSalary();
		}
		return result;
	}

	/**
	 * This method calculates average salary of employees
	 * @return - int - average salary
	 * @throws ArithmeticException
	 */
	public double getAverageSalary() throws ArithmeticException{
		double total = 0;
		int idx = 0;
		
		//Throw Exception when there is zero Employee
		//if(eCount == 0) throw new ArithmeticException();
		
		for(Employee e : emp_list){
			if(idx++ < eCount)
				total += e.getSalary();
		}
		// Update: change to following based on comment for 0 division
		if (Double.isInfinite(total/eCount) || Double.isNaN(total/eCount))
		        throw new ArithmeticException("Exception - No employee exists.");
		return total/eCount;
	}
	
	        /**
         * This method calculates average salary of employees
         * @return - int - average salary
         * @throws ArithmeticException
         */
        public double getAverageSalaryWrong() throws ArithmeticException{
                double total = 0;
                int idx = 0;

                //Throw Exception when there is zero Employee
                //if(eCount == 0) throw new ArithmeticException();

                for(Employee e : emp_list){
                        if(idx++ < eCount)
                                total += e.getSalary();
                }
                // Update: change to following based on comment for 0 division
                if (Double.isInfinite(total/eCount) || Double.isNaN(total/eCount))
                        throw new ArithmeticException("Exception - No employee exists.");
                return total/eCount + 10;
        }
		
	/**
	 * This method prints employees in the array
	 */
	public void printEmployees(){
		int idx = 0;
		for(Employee e : emp_list)
			if(idx++ < eCount)
				e.printEmployee();
	}
	
	/**
	 * This method cleans up the employee array
	 */
	public void clearAll(){
		for(int i = 0; i < eCount; i++)
			emp_list[i] = null;
		eCount = 0;
	}
	/**
	 * This method retrieves number of Employee objects in the array
	 * @return - int - eCount
	 */
	public int getCount(){
		return eCount;
	}
	
}
