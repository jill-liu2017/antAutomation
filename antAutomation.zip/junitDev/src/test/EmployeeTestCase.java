
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;



/**
 * 
 * @author Zhihong Liu
 * This class create a test application 
 * to verify methods in class EmployeeApp 
 * using junit4. 
 * This test case is converted from Junit3.
 */
public class EmployeeTestCase{

	/**
	 * private EmployeeApp
	 */
	private EmployeeApp eApp1;
	private EmployeeApp eApp2;
	private EmployeeApp eApp3; 
	

	/**
	 * This method initializes eApp1, eApp2, eApp3
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		// Two employees
		eApp1 = new EmployeeApp();
		eApp1.addEmployee("Jack1", 1000);
		eApp1.addEmployee("Jill1", 2000);

		// Five employees
		eApp2 = new EmployeeApp();
		eApp2.addEmployee("Jack2",  1000);
		eApp2.addEmployee("Jill2",  6000);
		eApp2.addEmployee("Jason2", 3000);
		eApp2.addEmployee("John2",  4000);
		eApp2.addEmployee("Jim2",   5000);

		// zero employee
		eApp3 = new EmployeeApp();
	}

	/**
	 * This method cleans up eApp1, eApp2, eApp3
	 */
	@After
	public void tearDown() throws Exception {
		eApp1.clearAll();
		eApp2.clearAll();
		eApp3.clearAll();
		eApp1 = null;
		eApp2 = null;
		eApp3 = null;
	}

	/**
	 * This method verifies EmployeeApp constructor
	 * with Employee[] as input parameter
	 */
	@Test
	public void testPrintEmployee() {
		EmployeeApp eApp4;
		Employee[] emp = new Employee[3];
		emp[0] = new Employee(1, "Herry", 1000);
		emp[1] = new Employee(2, "Chris", 2000);
		emp[2] = new Employee(3, "Jennifer", 3000);
		eApp4 = new EmployeeApp(emp);
		//eApp4.printEmployees();
		assertEquals((int)3, eApp4.getCount());
	}

	/**
	 * This method verifies the result of addEmployee()
	 */
	@Test
	public void testCreateEmployeeApp() {
		assertEquals((int)2, eApp1.getCount());
		assertEquals((int)5, eApp2.getCount());
		assertEquals((int)0, eApp3.getCount());
	}
	

	/**
	 * This method verifies that no more Employee can be added to the array
	 * when EmployeeApp's array capacity has been reached.
	 * IndexOutOfBoundsException is thrown
	 */
	@Test(expected = IndexOutOfBoundsException.class)
	public void testAddEmployeeOverCapacity(){
		eApp2.addEmployee("James2",   8000);
	}

	/**
	 * This method verifies that IndexOutOfBoundsException
	 * is thrown if EmployeeApp object is initialized with
	 * a array whose length is longer than EmployeeApp's 
	 * internal array capacity 
	 */
	@Test(expected = IndexOutOfBoundsException.class)
	public void testCreateEmployeeAppOverCapacity() {
		EmployeeApp eApp4;
		Employee[] emp = new Employee[6];
		emp[0] = new Employee(1, "Herry", 1000);
		emp[1] = new Employee(2, "Chris", 2000);
		emp[2] = new Employee(3, "Jennifer", 3000);
		emp[3] = new Employee(4, "Suzanne", 4000);
		emp[4] = new Employee(5, "Jim", 5000);
		emp[5] = new Employee(6, "James", 6000);
		eApp4 = new EmployeeApp(emp);
		eApp4.printEmployees();
		assertEquals(3, eApp4.getCount());
	}

	/**
	 * This method verifies minimum salary of employees
	 */
	@Test
	public void testGetMinSalary() {
		assertEquals(1000, eApp2.getMinSalary(), 0.001);
	}

	/**
	 *This method verifies maximum salary of employees
	 */
	@Test
	public void testGetMaxSalary() {
		assertEquals(6000, eApp2.getMaxSalary(), 0.001);
	}
	
	/**
	 * This method verifies average salary of employees
	 */
	@Test
	public void testGetAverageSalary() {
		assertEquals(3800, eApp2.getAverageSalary(), 0.001);
	}

	/**
	 * This method verifies average salary of employees
	 * when the array contains zero employee
	 * It expects ArithmeticException
	 */
	@Test(expected = ArithmeticException.class)
	public void testGetAverageEmptySalary() {
		eApp3.getAverageSalary();
	}

    /**
     * This method verifies average salary of employees
     * but intentionally return wrong answer from
     * testGetAverageSalaryWrong()
     * This test should fail with Failure
     */
    @Test
    public void testGetAverageSalaryWrong() {
            assertEquals(3800, eApp2.getAverageSalaryWrong(), 0.001);
        }
		
    /**
     * This method intentionally generates failure
     * It does not contain "expected" keyword
     * while Exception ArithmeticException is returned
     * from the assertion
     * This test should fail with Error
     */
    @Test
    public void testGetAverageEmptySalaryFailure() {
            eApp3.getAverageSalary();
    }
	
	
	/**
	 * This is main method which makes 
	 * junit test cases to run as application, and print out the test result 
	 * @param args
	 */
	public static void main(String[] args){

		Result result = JUnitCore.runClasses(EmployeeTestCase.class);
		
		System.out.println("Was test successfuly? " + result.wasSuccessful());
		System.out.println("How many test cases tested?" + result.getRunCount());
		System.out.println("How many failed? " + result.getFailureCount());
		for (Failure failure : result.getFailures()){
			System.out.println(failure.getMessage());
		}

	}

}
