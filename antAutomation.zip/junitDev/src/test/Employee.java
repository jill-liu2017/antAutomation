
public class Employee {

	private int id;
	private String name;
	private double salary;
	
	/**
	 * Constructor	
	 * @param i
	 * @param n
	 * @param s
	 */
	public Employee(int i, String n, double s){
		id = i;
		name = n;
		salary = s;
	}
	
	/**
	 * This method sets id
	 * @param i
	 */
	public void setId(int i){
		id = i;
	}
	
	/**
	 * This method sets name
	 * @param n
	 */
	public void setName(String n){
		name = n;
	}
	
	/** 
	 * This method sets salary
	 * @param s
	 */
	public void setSalary(double s){
		salary = s;
	}

	/**
	 * This method retrieves id
	 * @return - int - id
	 */
	public int getId(){
		return id;
	}
	
	/**
	 * This method retrieves name
	 * @return - String - name
	 */
	public String getName(){
		return name;
	}
	
	/**
	 * This method retrieves salary
	 * @return - double - salary
	 */
	public double getSalary(){
		return salary;
	}
	
	/**
	 * This method prints Employee object
	 */
	public void printEmployee(){
		System.out.println("Employee id: " + id);
		System.out.println("Employee name: " + name);
		System.out.println("Employee salary: " + salary);
	}

}
